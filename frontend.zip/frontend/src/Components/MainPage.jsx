import React from "react";
const MainPage = () => {
  return (
   <div>Hello world</div>
  );
};

export default MainPage;
